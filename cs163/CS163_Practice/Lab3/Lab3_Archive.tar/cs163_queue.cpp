#include "cs163_queue.h"


//Implement these functions using a Circular Linked List
//Add at the rear
int queue::enqueue(const journal_entry & to_add)
{
	//Write the function here
}

//Remove the node at the front
int queue::dequeue ()
{

	//Write the function here
}

