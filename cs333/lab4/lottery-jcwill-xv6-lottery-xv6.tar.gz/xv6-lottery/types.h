typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
#ifdef PROC_TIMES
typedef unsigned long ulong;
#endif // PROC_TIMES
typedef uint pde_t;
