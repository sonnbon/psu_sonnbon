#ifdef PROC_TIMES

#pragma once
# ifndef __RAND_H
#  define __RAND_H

#include "types.h"

#  define RAND_MAX (1 << 31)

int rand(void);        // Generate pseudo-random integer
void srand(uint);      // Set seed for new sequence of pseudo-random integers
# endif // __RAND_H
#endif // PROC_TIMES
