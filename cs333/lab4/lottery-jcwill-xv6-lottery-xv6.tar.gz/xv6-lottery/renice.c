#include "types.h"
#include "stat.h"
#include "user.h"

// Command alters priority of running processes (taken from man pages)
int
main (int argc, char *argv[])
{
#ifdef LOTTERY
    int count = 0;    //Counts iterations
    int fails = 0;    //Counts non-existent pids

    //Check for correct number of command line arguments.
    if (argc < 3) {
        printf(1, "renice failed for number of args %d\n", argc);
        exit();
    }

    //Loop through processes and change nice values of matching pids.
    for (int i = 2; argv[i]; i++) {
        if (renice(atoi(argv[i]), atoi(argv[1])) == 2) {
            ++fails;
        }
        ++count;
    }

    //Check if all pids exist.
    if (count == fails) {
        printf(1, "renice failed for all pids\n");
        exit();
    }
#endif // LOTTERY
    exit(); 
}
