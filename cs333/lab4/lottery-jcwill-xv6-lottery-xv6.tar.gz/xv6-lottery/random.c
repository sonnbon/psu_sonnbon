#ifdef PROC_TIMES

#include "types.h"
#include "stat.h"
#include "user.h"

// Command generates a list of 10 pseudo-random integers.
int
main(int argc, char *argv[])
{
    if (argc > 1) {
        srand(atoi(argv[1]));
    }

    for (int i = 0; i < 10; ++i) {
        printf(1,"random number is: %d\n", rand());
    }
    exit();
}
#endif // PROC_TIMES
