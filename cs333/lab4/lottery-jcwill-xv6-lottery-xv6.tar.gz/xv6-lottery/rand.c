#ifdef PROC_TIMES

#include "rand.h"

static ulong next = 1; // Initial seed value for rand/srand

// This function returns a pseudo-random integer in the range 0 to RAND_MAX
// inclusive (taken from man pages).
int
rand(void)
{
    next = next * 1103515245 + 12345;
    return((unsigned)(next/65536) % RAND_MAX);
}



// This function sets its argument as the seed for a new sequence of
// pseudo-ranom integers to be returned by rand(). These sequences are
// repeatable by calling srand() with the same seed value (take from man 
// pages).
void
srand(uint seed)
{
    next = seed;
}
#endif // PROC_TIMES
