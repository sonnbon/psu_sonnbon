#include "types.h"
#include "stat.h"
#include "user.h"

// Command adjusts niceness, which affects process scheduling (taken from man
// page) 
int
main (int argc, char *argv[])
{
#ifdef LOTTERY
    int pid = getpid();
    int status = 0; //Check for renice success

    //Check for correct number of command line arguments.
    if (argc < 3) {
        printf(1, "nice failed for number of args %d\n", argc);
        exit();
    }

    status = renice(pid, atoi(argv[1]));

    //Check if the pid exists and that the nice value is in bounds.
    if (status == 1) {
        printf(1, "nice input out of bounds, nice value unchanged or defaults\n");
    }
    else if (status == 2) {
        printf(1, "nice failed for non-existent pid %d\n", pid);
        exit();
    }
    exec(argv[2], &argv[2]);
    printf(1, "nice failed for pid %d\n", pid);
#endif // LOTTERY
    exit(); 
}
