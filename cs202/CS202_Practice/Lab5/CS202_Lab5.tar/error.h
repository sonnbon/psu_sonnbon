
struct NULL_STRING
{
    char * street;
    char * zip;
};

struct INVALID_PAY
{
    float pay_rate;
};

struct too_long
{
    int extra;
};
